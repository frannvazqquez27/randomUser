Ahí es lo que está subido en github: https://github.com/frannvazqquez27/randomUser/tree/gh-pages
Ahí está en github pages funcionando: https://frannvazqquez27.github.io/randomUser/